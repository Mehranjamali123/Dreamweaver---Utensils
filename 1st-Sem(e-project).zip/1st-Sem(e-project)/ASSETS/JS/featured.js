var products=[
    {
        img:'ASSETS/IMG/f-product.jpg',
        title:'Simple Crockary',
        h5:'Rs:2500',
        btn:'Add to Card',
        
    },
    {
        img:'ASSETS/IMG/product1.jpg',
        title:'Utensils Tool',
        h5:'Rs:1800',
        btn:'Add to Card',
       
    },
    {
        img:'ASSETS/IMG/product2.jpg',
        title:'Cups Set',
        h5:'Rs:2200',
        btn:'Add to Card',
        
    },
    {
        img:'ASSETS/IMG/product4.jpg',
        title:'Mud Cruckery',
        h5:'Rs:2000',
        btn:'Add to Card',
       
    },
    {
        img:'ASSETS/IMG/product5.jpg',
        title:'Crockery',
        h5:'Rs:3300',
        btn:'Add to Card',
       
    },
    {
        img:'ASSETS/IMG/product6.jpg',
        title:'Wood Spoons',
        h5:'Rs:1000',
        btn:'Add to Card',
       
    },
    {
        img:'ASSETS/IMG/product7.jpg',
        title:'Electric kattel',
        h5:'Rs:3500',
        btn:'Add to Card',
       
    },
    {
        img:'ASSETS/IMG/product8.jpg',
        title:'Port',
        h5:'Rs:2000',
        btn:'Add to Card',
       
    },
    {
        img:'ASSETS/IMG/mugs/img1',
        title:'Mugs',
        h5:'RS : 1000',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img2',
        title:'mugs',
        h5:'RS : 3000',
        btn:'Add to Card', 
    },
    {
        img:'ASSETS/IMG/mugs/img5',
        title:'mugs',
        h5:'RS : 1500',
        btn:'Add to Card',  
    },
    {
        img:'ASSETS/IMG/kitchentool/img1.jpg',
        title:'kitchentool',
        h5:'RS : 2500',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/kitchentool/img14.jpeg',
        title:'kitchentool',
        h5:'RS : 3500',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/kitchentool/img6.jpg',
        title:'kitchentool',
        h5:'RS : 4500',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/cutlery/img9.jpg',
        title:'cutlery',
        h5:'RS : 1500',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/cutlery/img6.jpg',
        title:'cutlery',
        h5:'RS : 4000',
        btn:'Add to Card',
    },
]
  