var cutleryItem=[
    {
        img:'ASSETS/IMG/cutlery/images.jpg',
        title:'Title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img1.jpg',
        title:'itle',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img5.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img6.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img7.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img8.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img9.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img10.jpg',
        title:'Title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img11.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img12.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img13.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
    {
        img:'ASSETS/IMG/cutlery/img14.jpg',
        title:'title',
        price:'here',
        btn:'Add to card',
    },
]